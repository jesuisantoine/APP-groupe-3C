function toggleForm() {
    var form = document.getElementById("add_condition");
    if (form.style.display === "none") {
        form.style.display = "block";
    } else {
        form.style.display = "none";
    }
}