function toggleForm() {
    var form = document.getElementById("addQuestionForm");
    if (form.style.display === "none") {
        form.style.display = "block";
    } else {
        form.style.display = "none";
    }
}
